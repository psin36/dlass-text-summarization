#!/bin/sh
pip3 install -r requirements.txt --no-index --find-links ${DATA_DIR}
mkdir -p /usr/share/nltk_data/tokenizers
unzip ${DATA_DIR}/punkt.zip -d /usr/share/nltk_data/tokenizers/ 
python3 train.py --train_article_path ${DATA_DIR}/sumdata/train/train.article.txt --train_title_path ${DATA_DIR}/sumdata/train/train.title.txt --valid_article_path ${DATA_DIR}/sorcerers_stone_copy.txt --valid_title_path ${DATA_DIR}/chapter_summaries.txt --results ${RESULT_DIR}/results-7-13-1_40.txt
python3 test.py 

