The accompanying script can be used to set up your IBM Watson Machine Learning deep learning environment.
