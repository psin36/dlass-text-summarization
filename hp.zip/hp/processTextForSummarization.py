import fileinput
import re

##replace all periods with 2 commas, replaces all numbers with #,
##concatenates all sentences into one long line (no line breaks),
##breaks line at each chapter (so each chapter is one one line),
##makes everything lowercase

with fileinput.input(files=('chamber_of_secrets.txt'), inplace=True) as f:
    for s in f:
        s = s.replace('.',',,')
        s = re.sub('\d','#', s)
        s = re.sub('\n',' ', s)
        s = s.replace('CHAPTER', '\n')
        s = s.lower()
        print(s, end='')
    fileinput.close()
