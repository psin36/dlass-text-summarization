import fileinput


def process(line):
    print(line+".")

with fileinput.input(files=('valid.title.filter.EOS.txt'), inplace=True) as f:
    for line in f:
        print(line+".")
    fileinput.close()
