#!/bin/sh
set -xe

python3 -u DeepSpeech.py \
  --train_batch_size 8 \
  --dev_batch_size 8 \
  --test_batch_size 8 \
  --learning_rate 0.0001 \
  --epoch 15 \
  --display_step 5 \
  --validation_step 5 \
  --dropout_rate 0.30 \
  --default_stddev 0.046875 \
  --checkpoint_dir "$checkpoint_dir" \
  "$@"
